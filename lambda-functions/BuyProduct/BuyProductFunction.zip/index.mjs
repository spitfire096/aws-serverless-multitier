// lambda-functions/BuyProductFunction/index.mjs

import mysql from 'mysql2/promise';

export const handler = async (event) => {
  // Define CORS headers to include in all responses
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT",
    "Access-Control-Allow-Headers": "Content-Type,Authorization"
  };

  let connection;

  try {
    console.log("Received event:", JSON.stringify(event));

    // Check HTTP method if you want to allow only POST
    if (event.httpMethod && event.httpMethod !== 'POST') {
      return {
        statusCode: 405,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Method Not Allowed' })
      };
    }

    // Handle request body parsing
    let body;
    if (typeof event.body === 'string') {
      try {
        body = JSON.parse(event.body);
      } catch (parseError) {
        throw new Error("Failed to parse JSON body: " + parseError.message);
      }
    } else if (typeof event.body === 'object' && event.body !== null) {
      body = event.body;
    } else {
      throw new Error("Request body is not valid JSON.");
    }

    const { productId } = body;
    if (!productId) {
      throw new Error("Missing required field: productId");
    }

    // In a real-world scenario, you'd parse or validate the token from event.headers.Authorization
    // For simplicity here, let's assume you have some userSub available from token or body
    // For example: decode JWT to get userSub. We'll just show it as a mock:
    const userSub = "mocked-sub-123"; // replace with actual logic

    // Create a MySQL connection using mysql2/promise
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER,
      password: process.env.DB_PASS,
      database: process.env.DB_NAME,
      connectTimeout: 5000
    });

    // 1) Check if product is still available (status = 'available')
    const [productRows] = await connection.execute(
      'SELECT status FROM products WHERE id = ?',
      [productId]
    );

    if (!productRows.length) {
      throw new Error("Product not found.");
    }

    if (productRows[0].status !== 'available') {
      throw new Error("Product is not available.");
    }

    // 2) Mark product as sold
    await connection.execute(
      `UPDATE products
       SET status = 'sold', updated_at = NOW()
       WHERE id = ?`,
      [productId]
    );

    // 3) Insert a record in the purchases table
    await connection.execute(
      `INSERT INTO purchases (product_id, buyer_sub, purchased_at)
       VALUES (?, ?, NOW())`,
      [productId, userSub]
    );

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Product purchased successfully.' }),
    };
  } catch (error) {
    console.error('Error buying product:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Error buying product.',
        details: error.message
      }),
    };
  } finally {
    if (connection) {
      try {
        await connection.end();
      } catch (endError) {
        console.error('Error ending connection:', endError);
      }
    }
  }
};
